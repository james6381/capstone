import numpy as np
import math
#from simulation_fcts_v2 import get_parameters
#from simulation_fcts_v2 import get_1gbmpath
from simulation_fcts_v3 import get_parameters
from simulation_fcts_v3 import get_1gbmpath

SP500 = np.genfromtxt('SP500_data.csv', delimiter=',')
BND = np.genfromtxt('BND_data.csv', delimiter=',')

ret_SP500, mu_SP500, sig_SP500 = get_parameters(SP500)
ret_BND, mu_BND, sig_BND = get_parameters(BND)

# print(mu_SP500, sig_SP500, mu_BND, sig_BND)

temp = np.zeros((ret_SP500.size,2))  # temp matrix for [SP500, BND]
counter = 0
while counter < SP500.size-1:
    temp[counter,0] = ret_SP500[counter]
    temp[counter,1] = -1*ret_BND[counter]     # see note below
    counter += 1

corrmatrix = np.corrcoef(temp.T)    # for numpy, each row represents a variable, and columns are the observations
# **NOTE If case SP500 and BND have negative correlation -> matrix will not be positive definite
# then, multiply the second set of numbers and the correlation by -1?

seeding = 10001     # so far, have used seeds 0-10000
N = 100    # number of simulation runs
results = np.zeros((N,2))

counter = 0
while counter < N:
    temp = get_1gbmpath(mu_SP500, sig_SP500, mu_BND, sig_BND, corrmatrix, 1./252., 252*5, seeding+counter)
    results[counter, 0] = temp[0]
    results[counter, 1] = temp[1]
    #print('%.8f , %.8f' % (results[counter, 0], results[counter, 1]))   # display results of simulation
    counter += 1

#print results
#print '---------'
ind = np.lexsort((results[:,1], results[:,0])) # returns sorting order if sorted by stock returns then bond returns
results[:,0] = [results[i,0] for i in ind]
results[:,1] = [results[i,1] for i in ind]
print results
print '--------'

# get the stock and bond factors for each of the 4 scenario from the sorted empirical distribution
# this ensures correlations remain b/w assets for each scenario
# using math.ceil to ensure first term is an integer
stock_1 = np.mean(results[0:int(math.ceil(0.25 * N)) - 1, 0])
# mean of stock returns between 0% percentile and first quartile of disttribution
stock_2 = np.mean(results[int(math.ceil(0.25 * N)): int(math.ceil(0.5 * N)) - 1, 0])
# mean of stock returns b/w 1st and 2nd quartile
stock_3 = np.mean(results[int(math.ceil(0.5 * N)): int(math.ceil(0.75 * N)) - 1, 0])
# mean of stocks b/w 2nd and 3rd quartile
stock_4 = np.mean(results[int(math.ceil(0.75 * N)): N - 1, 0])
# mean of stocks b/w 3rd and 4th quartile
# repeating for bonds
bond_1 = np.mean(results[0:int(math.ceil(0.25 * N)) - 1, 1])
bond_2 = np.mean(results[int(math.ceil(0.25 * N)): int(math.ceil(0.5 * N)) - 1, 1])
bond_3 = np.mean(results[int(math.ceil(0.5 * N)): int(math.ceil(0.75 * N)) - 1, 1])
bond_4 = np.mean(results[int(math.ceil(0.75 * N)): N - 1, 1])

print np.array([stock_1, stock_2, stock_3, stock_4, bond_1, bond_2, bond_3, bond_4])

import numpy as np
import math
from get_yaml import get_profile
from simulation_fcts_v2 import get_ud
from DSPopt import get_DSPopt
#from DSPopt_v2 import get_DSPopt

# # GETTING PROFILE DATA FROM UI
year, goal, goalmin, liab, inc = get_profile()
t = year.size  # get time horizon
t_period = math.ceil(t / (5+1))  # get time period length; can only have 5+1 periods (including time 0)
                                    # o/w problem becomes too large

MM_return = 1.005   # risk free return


# # GROUPING UP AMOUNTS FOR GOALS, INCOMES & LIABILITIES INTO EACH TIME PERIOD STAGE
goal2 = np.zeros((5+1, 1))  # 5+1 rows because 1 for each time period + 1 for time 0
goalmin2 = np.zeros((5+1, 1))
liab2 = np.zeros((5+1, 1))
inc2 = np.zeros((5+1, 1))

period_counter = 0  # we start at row index 1 because initial year has its own row
year_counter = 0
while period_counter < 5+1:
    temp_goal = 0
    temp_goalmin = 0
    temp_liab = 0
    temp_inc = 0
    temp_counter = 0
    while year_counter < period_counter*t_period:  # discounting all values in between periods to the start of a period
        temp_goal += goal[year_counter] / (MM_return**(temp_counter))
        temp_goalmin += goalmin[year_counter] / (MM_return ** (temp_counter))
        temp_liab += liab[year_counter] / (MM_return ** (temp_counter))
        temp_inc += inc[year_counter] / (MM_return ** (temp_counter))
        temp_counter += 1
        year_counter += 1

    goal2[period_counter] = temp_goal   # assigning the total discounted period amounts
    goalmin2[period_counter] = temp_goalmin
    liab2[period_counter] = temp_liab
    inc2[period_counter] = temp_inc
    period_counter += 1


# # RUN SIMULATION TO GET PERIOD UP, DOWN FACTORS FOR STOCKS AND BONDS
ret_scenario = get_ud(t_period)


# # FEEDING INTO 2 OPTIMIZATIONS w/ DIFFERENT RISK COEF AND LIABILITY PENALTY COEF
risk_coef1 = -4.    # ENSURE THESE ARE DOUBLES
liab_coef1 = -10.
optresult1 = get_DSPopt(ret_scenario, goal2, goalmin2, liab2, inc2, risk_coef1)
#optresult1 = get_DSPopt(ret_scenario, goal2, goalmin2, liab2, inc2, risk_coef1, liab_coef1)

risk_coef2 = -10.
liab_coef2 = -15.
optresult2 = get_DSPopt(ret_scenario, goal2, goalmin2, liab2, inc2, risk_coef2)
#optresult2 = get_DSPopt(ret_scenario, goal2, goalmin2, liab2, inc2, risk_coef2, liab_coef2)


# # READING OPTIMIZATION RESULTS
allocation1 = np.zeros((optresult1.size*3/5, 3))
goal_perf1 = np.zeros((optresult1.size*2/5, 2))
allocation2 = np.zeros((optresult2.size*3/5, 3))
goal_perf2 = np.zeros((optresult2.size*2/5, 2))

counter = 0
row_counter = 0
while counter < optresult1.size*3/5:     # reading the solution vector to get asset allocations
    allocation1[row_counter,0] = optresult1[counter]
    allocation1[row_counter,1] = optresult1[counter+1]
    allocation1[row_counter, 2] = optresult1[counter + 2]

    allocation2[row_counter, 0] = optresult2[counter]
    allocation2[row_counter, 1] = optresult2[counter + 1]
    allocation2[row_counter, 2] = optresult2[counter + 2]

    row_counter += 1
    counter += 3

row_counter = 0
while counter < optresult1.size:    # reading the solution vector to get goal shortfall/excess
    goal_perf1[row_counter, 0] = optresult1[counter]
    goal_perf1[row_counter, 1] = optresult1[counter + 1]

    goal_perf2[row_counter, 0] = optresult2[counter]
    goal_perf2[row_counter, 1] = optresult2[counter + 1]

    row_counter += 1
    counter +=2


# # CALCULATING AVERAGE ASSET ALLOCATION AT EACH TIME PERIOD
# 3 assets, 4 branches per node (assets with 2 possibilities; 2**2), 6 time periods (including time 0)
avg_allocation1 = np.zeros((6,3))
avg_allocation2 = np.zeros((6,3))

asset_counter = 0
while asset_counter < 3:
    period_counter = 0
    row_counter = 0
    while period_counter < 6:
        temp_avg1 = 0
        temp_avg2 = 0
        s_counter = 0
        while s_counter < 4**period_counter:    # looping to get all allocations for all scenarios in a time period
            temp_avg1 += allocation1[row_counter, asset_counter] / (np.sum(allocation1[row_counter,:]))
            temp_avg2 += allocation2[row_counter, asset_counter] / (np.sum(allocation1[row_counter,:]))
            s_counter += 1
            row_counter += 1
        # getting expected allocation of an asset per time period
        avg_allocation1[period_counter, asset_counter] = temp_avg1 / (4**period_counter)
        avg_allocation2[period_counter, asset_counter] = temp_avg2 / (4**period_counter)
        period_counter += 1
    asset_counter += 1


# # CALCULATING EXPECTED WEALTH AT EACH TIME PERIOD
# 3 assets, 4 branches per node (assets with 2 possibilities; 2**2), 6 time periods (including time 0)
avg_wealth1 = np.zeros((6, 1))
avg_wealth2 = np.zeros((6, 1))

period_counter = 0
row_counter = 0
while period_counter < 6:
    temp_wealth1 = 0
    temp_wealth2 = 0
    s_counter = 0
    while s_counter < 4 ** period_counter:  # looping to get total amount of wealth for all scenarios in a time period
        temp_wealth1 += (np.sum(allocation1[row_counter, :]))
        temp_wealth2 += (np.sum(allocation1[row_counter, :]))
        s_counter += 1
        row_counter += 1
    # getting expected wealth in a time period
    avg_wealth1[period_counter, asset_counter] = temp_wealth1 / (4**period_counter)
    avg_wealth2[period_counter, asset_counter] = temp_wealth2 / (4**period_counter)
    period_counter += 1


# # CALCULATING EXPECTED % OF TIME GOALS ARE MET PER TIME PERIOD
# 3 assets, 4 branches per node (assets with 2 possibilities; 2**2), 6 time periods (including time 0)
exp_per1 = np.zeros((6,1))
exp_per2 = np.zeros((6,1))

period_counter = 0
row_counter = 0
while period_counter < 6:
    temp_counter1 = 0
    temp_counter2 = 0
    s_counter =1
    while s_counter < 4**period_counter:
        if goal_perf1[row_counter,1] > 0:       # increment if we had a goal excess amount
            temp_counter1 += 1
        if goal_perf2[row_counter, 1] > 0:      # increment if we had a goal excess amount
            temp_counter2 += 1
        s_counter += 1
        row_counter += 1
    # getting percentage of time we had goal excess
    exp_per1[period_counter] = temp_counter1 / (4**period_counter)
    exp_per2[period_counter] = temp_counter2 / (4**period_counter)
    period_counter += 1


# # NEED TO SAVE RESULTS and export to excel
import numpy as np
import random

def get_empirical(price_data):
    ret = np.zeros((price_data.size-1, 1))

    counter = 0
    while counter < price_data.size-1:  # get log returns of the asset
        ret[counter] = (price_data[counter]/price_data[counter+1])     # this is because data is sorted from new to old
        counter += 1

    empirical = np.zeros((ret.size, 1))
    counter = 0
    while counter < ret.size:   # getting the empirical cdf probabilities (sorted rank)/number of observations
        empirical[counter] = np.float64(counter+1)/np.float64(ret.size)
        counter += 1

    return ret, empirical

    # # NEED TO SAVE TO DATABASE in main code
    #
    #


def run_1simulation(ret1, empirical1, ret2, empirical2, corrmatrix, t, seeding):
    # ret should be SORTED
    # using 2 assets: S&P500, Vanguard Total Bond Index (BND)
    # assume constant risk free return from MM

    randmatrix = np.zeros((t, 2))

    random.seed(seeding)
    counter = 0
    while counter < t:      # load in unif(0,1) random numbers in randMatrix
        randmatrix[counter, 0] = random.random()
        randmatrix[counter, 1] = random.random()
        counter += 1

    randmatrix = randmatrix.dot(np.linalg.cholesky(corrmatrix).T)   # M = M*chol(corr);
    # generating 2 correlated sets of random numbers
    # using upper triang rather than lower triang matrix, thus Transpose
    # print(np.corrcoef(randmatrix.T))  # checking if method worked

    counter = 0
    while counter < t:  # correcting certain numbers generated from the decomposition (some are > 1; about 5%)
        if randmatrix[counter,1] > 1:
            randmatrix[counter,1] = randmatrix[counter,1] -1
        counter += 1

    randset = np.zeros((t, 2))

    counter = 0
    while counter < t:
        counter2 = 0    # converting unif(0,1) random number to a log return for the 1st asset
        while empirical1[counter2] < randmatrix[counter, 0] and counter2 < np.size(empirical1)-1:
            # 'or' argument to prevent inf loops
            # finding conversion index
            # compares the empirical cdf with the random unif(0,1) number to get the log_ret value when converted
            counter2 += 1
        randset[counter,0] = ret1[counter2]   # saving the converted random number

        # Repeating for the 2nd asset
        counter2 = 0
        while empirical2[counter2] < randmatrix[counter, 1] and counter2 < np.size(empirical2)-1:
            counter2 += 1
        randset[counter, 1] = ret2[counter2]*-1
        #print(randmatrix[counter,1])
        #print(randset[counter,1])

        counter += 1

    results = np.ones((2,1))   # will store 5 year return simulation results
    counter = 0
    while counter < t:
        results[0] *= randset[counter,0]
        results[1] *= randset[counter,1]
        counter += 1

    return results


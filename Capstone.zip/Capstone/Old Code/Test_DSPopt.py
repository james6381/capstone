import numpy as np
#from DSPopt_v2 import get_DSPopt
from DSPopt import get_DSPopt


ret_scenario = np.array([1.52, 0.79, 1.12, 0.96, 1.005])
goal = np.array([0., 0., 0., 0., 0., 80000.])
goalmin = np.zeros((6,1))
liab = ([0., 0., 0., 0., 5000., 0.])
inc = ([55000., 1000., 1000., 1000., 1000., 1000.])
risk_coef = -2.    # ENSURE THIS IS A DOUBLE
liab_coef = -15.

result = get_DSPopt(ret_scenario, goal, goalmin, liab, inc, risk_coef)

counter = 0
while counter < result.size*3/5:    # print allocations
    print ('%.2f, %.2f, %.2f' %(result[counter], result[counter+1], result[counter+2]))
    counter += 3
while counter < result.size*5/5:    # print shortfall and above amounts
    print ('%.2f, %.2f' % (result[counter], result[counter+1]))
    counter +=2


#result = get_DSPopt(ret_scenario, goal, goalmin, liab, inc, risk_coef, liab_coef)
#
#counter = 0
#while counter < result.size * 3 / 6:  # print allocations
#    print ('%.2f, %.2f, %.2f' % (result[counter], result[counter + 1], result[counter + 2]))
#    counter += 3
#while counter < result.size * 5 / 6:  # print shortfall and above amounts
#    print ('%.2f, %.2f' % (result[counter], result[counter + 1]))
#    counter += 2
#while counter < result.size:  # print shortfall of liabilities
#    print ('%.2f' % (result[counter]))
#    counter += 1
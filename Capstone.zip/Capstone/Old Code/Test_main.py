import numpy as np
import math
import csv
from get_yaml import get_profile
from simulation_fcts_v3 import get_scenarios
from DSPopt_v3 import get_DSPopt


# # GETTING PROFILE DATA FROM UI
goal, goalmin, liab, inc, t, t_period = get_profile(1.005)
#t = year.size  # get time horizon
#t_period = math.ceil((t-1) / (5))  # get time period length; can only have 5+1 periods (including time 0)
                                    # o/w problem becomes too large

#MM_return = 1.005   # risk free return


## # GROUPING UP AMOUNTS FOR GOALS, INCOMES & LIABILITIES INTO EACH TIME PERIOD STAGE
#goal2 = np.zeros((5+1, 1))  # 5+1 rows because 1 for each time period + 1 for time 0
#goalmin2 = np.zeros((5+1, 1))
#liab2 = np.zeros((5+1, 1))
#inc2 = np.zeros((5+1, 1))

#period_counter = 1 # we start at row index 1 because initial year has its own row
#year_counter = 1
#inc2[0] = inc[0]
#while period_counter < 5+1:
#    temp_goal = 0
#    temp_goalmin = 0
#    temp_liab = 0
#    temp_inc = 0
#    temp_counter = 0
#    while year_counter < (period_counter)*t_period +1:  # discounting all values in between periods to the start of a period
#        temp_goal += goal[year_counter] / (MM_return**(temp_counter))
#        temp_goalmin += goalmin[year_counter] / (MM_return ** (temp_counter))
#        temp_liab += liab[year_counter] / (MM_return ** (temp_counter))
#        temp_inc += inc[year_counter] / (MM_return ** (temp_counter))
#        temp_counter += 1
#        year_counter += 1
#
#    goal2[period_counter] = temp_goal   # assigning the total discounted period amounts
#    goalmin2[period_counter] = temp_goalmin
#    liab2[period_counter] = temp_liab
#    inc2[period_counter] = temp_inc
#    period_counter += 1

print goal
print t, t_period
print liab
print inc
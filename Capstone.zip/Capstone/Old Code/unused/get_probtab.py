import numpy as np

def get_prob(time_horizon, time_step, sim_results):
    sim_results = np.genfromtxt('MIE479_simulationresults_v2.csv', delimiter=',')   # importing simulation results

    # s = 3       # number of scenarios per asset branch
    # n = 2       # number of assets
    tab = np.zeros((2**2,1))

    u1 = 1.5    # setting the scenario branching factors u, d; 1 for SP500, 2 for BND
    d1 = 0.7
    u2 = 1.1
    d2 = 0.95

    counter = 0
    while counter < sim_results[:,0].size:  # sorting all the results into a probability table for ONE TIMESTEP
        if sim_results[counter,0] >= 1.:
            if sim_results[counter,1] >= 1.:
                tab[0] += 1
            elif sim_results[counter,1] < 1.:
                tab[1] += 1

        elif sim_results[counter,0] < 1.:
            if sim_results[counter,1] >= 1.:
                tab[2] += 1
            elif sim_results[counter,1] < 1.:
                tab[3] += 1

        counter += 1

    #print(tab)
    #print(np.sum(tab))
    tab /= sim_results[:,0].size        # converting counts to percentages
    #print(tab)
    #print(np.sum(tab))

    prob_space = np.zeros((2**(2*5),1))
    counter = 0
    while counter < prob_space.size:





    return prob_space
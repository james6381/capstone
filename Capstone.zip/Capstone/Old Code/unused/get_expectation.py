from simulation_fcts import get_empirical
from simulation_fcts import run_1simulation
import numpy as np


SP500 = np.genfromtxt('SP500_data.csv', delimiter=',')
BND = np.genfromtxt('BND_data.csv', delimiter=',')

SP500_return, SP500_empirical = get_empirical(SP500)
BND_return, BND_empirical = get_empirical(BND)

temp = np.zeros((SP500_return.size,2))  # temp matrix for [SP500, BND]
counter = 0
while counter < SP500.size-1:
    temp[counter,0] = SP500_return[counter]
    temp[counter,1] = -1*BND_return[counter]     # see note below
    counter += 1

corrmatrix = np.corrcoef(temp.T)    # for numpy, each row represents a variable, and columns are the observations
# **NOTE If case SP500 and BND have negative correlation -> matrix will not be positive definite
# then, multiply the second set of numbers and the correlation by -1?

SP500_return = np.sort(SP500_return, axis=None)     # sorting the two matrices to match up with the empirical
BND_return = np.sort(BND_return, axis=None)

#BND_return[0] = BND_return[2]  # removing a few extreme values which is skewing results
#BND_return[1] = BND_return[2]


seeding = 500  # so far, have used seeds 0-500
N = 100 # number of simulation runs
results = np.zeros((N,2))

counter = 0
while counter < N:
    temp = run_1simulation(SP500_return, SP500_empirical, np.sort(-1*BND_return, axis=None), BND_empirical, corrmatrix, 240*5, seeding+counter)
    results[counter, 0] = temp[0]
    results[counter, 1] = temp[1]
    counter += 1
    print(counter)  # just to display progress of simulations

# using 2 assets: S&P500, Vanguard Total Bond Index (BND)
# assume constant risk free return from MM
# t = 240 * 5     # number of trading days in 5 years

print(results[:,0])
print(results[:,1])

# When running this code, WATCH your N (number of runs); if too large will take a LONG time

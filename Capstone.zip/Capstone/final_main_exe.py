import numpy as np
import csv
from get_yaml import get_profile
from simulation_fcts_v3 import get_scenarios
from DSPopt_v3 import get_DSPopt

MM_return = 1.005   # risk free return

# # GETTING PROFILE DATA FROM UI AND GROUPING UP AMOUNTS FOR GOALS, INCOMES & LIABILITIES INTO EACH TIME PERIOD STAGE
goal2, goalmin2, liab2, inc2, t, t_period = get_profile(MM_return)


# # RUN SIMULATION TO GET PERIOD UP, DOWN FACTORS FOR STOCKS AND BONDS
ret_scenario = get_scenarios(t_period)


# # FEEDING INTO OPTIMIZATIONS w/ DIFFERENT RISK COEFFICIENTS
risk_coef = -4.    # ENSURE THESE ARE DOUBLES
#risk_coef = -10.
#risk_coef = -15.
#risk_coef = -20.

optresult = get_DSPopt(ret_scenario, MM_return**t_period, goal2, goalmin2, liab2, inc2, risk_coef)
# note that the risk free rate is in years, thus we put it to the power of the time period duration


# # READING OPTIMIZATION RESULTS
allocation = np.zeros((optresult.size/5, 3))  # meant to hold all the asset allocations
goal_perf = np.zeros((optresult.size/5, 2))   # holds all the results of scenario over/under goal amounts

counter = 0
row_counter = 0
while counter < optresult.size*3/5:     # reading the solution vector to get asset allocations
    allocation[row_counter,0] = optresult[counter]
    allocation[row_counter,1] = optresult[counter+1]
    allocation[row_counter, 2] = optresult[counter + 2]
    row_counter += 1
    counter += 3

row_counter = 0
while counter < optresult.size:    # reading the solution vector to get goal shortfall/excess
    goal_perf[row_counter, 0] = optresult[counter]
    goal_perf[row_counter, 1] = optresult[counter + 1]
    row_counter += 1
    counter +=2


# # CALCULATING AVERAGE ASSET ALLOCATION AT EACH TIME PERIOD
# 3 assets, 4 branches per node (assets with 2 possibilities; 2**2), 6 time periods (including time 0)
avg_allocation = np.zeros((6,3))

asset_counter = 0
while asset_counter < 3:
    period_counter = 0
    row_counter = 0
    while period_counter < 6:
        temp_avg = 0
        s_counter = 0
        while s_counter < 4**period_counter:    # looping to get all allocations for all scenarios in a time period
            temp_avg += allocation[row_counter, asset_counter] / (np.sum(allocation[row_counter,:]))
            s_counter += 1
            row_counter += 1
        # getting expected allocation of an asset per time period
        avg_allocation[period_counter, asset_counter] = temp_avg / (4**period_counter)
        period_counter += 1
    asset_counter += 1


# # CALCULATING EXPECTED WEALTH AT EACH TIME PERIOD
# 3 assets, 4 branches per node (assets with 2 possibilities; 2**2), 6 time periods (including time 0)
avg_wealth = np.zeros((6, 1))

period_counter = 0
row_counter = 0
while period_counter < 6:
    temp_wealth = 0
    s_counter = 0
    while s_counter < 4 ** period_counter:  # looping to get total amount of wealth for all scenarios in a time period
        temp_wealth += (np.sum(allocation[row_counter, :]))
        s_counter += 1
        row_counter += 1
    # getting expected wealth in a time period
    avg_wealth[period_counter] = temp_wealth / (4**period_counter)
    period_counter += 1


# # WRITE RESULTS INTO CSV - should be written into a database, however this was not done by backend...
file = open('opt_results.csv', 'wb')
w = csv.writer(file)

w.writerows(avg_allocation)
w.writerows(avg_wealth)
w.writerows(allocation)
w.writerows(goal_perf)

file.close

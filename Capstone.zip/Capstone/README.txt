All files should be located in the same folder:
-BND_data.csv
-SP500_data.csv
-MIE479_UI_v2.xlsm
-DSPopt_v3.py
-final_main_exe.py
-get_yaml.py
-simulation_fcts_v3.py
-DSPopt_v3.pyc
-get_yaml.pyc
-simulation_fcts_v3.pyc

Should the environment not work, below is the python version and a list of all python packages that were used:

-Python 2.7
-cvxopt
-numpy
-PyYaml
-math
-random
-csv


To run this project:
-Open 'MIE479_UI_v2'
-Create your profile, add your goals, liabilities and income via the 'Create Profile', 'Create Goal', 'Create Liability', and 'Create Income' macro buttons. 
	Note that there is no input validation.
-Click on macro button 'Setup Results'. This should create a yaml file called 'test_profiledata.yaml'
-Then run the python script 'final_main_exe.py'. This should create a csv file called 'opt_results'.
-Once the script finishes, click the macro button 'Get Results'. This should load the 'opt_results.csv' file into the 'OptResults' spreadsheet.

-Note that changing risk coefficient value in the optimization has to be done the the python file 'final_main_exe.py' in line 18.


Results in 'opt_results.csv' will be in the form of:
	-Rows 1-6 will display your average asset allocation in stocks, bonds and risk-free per time period (6 time periods in investment horizon including time 0)
	Note that asset allocation at final time period does not matter as we have already reached the end of the investment horizon. It will generally be 33% across all asset types.
	-Rows 7-12 will display expected wealth at each time period
	-Row 13 will display optimal asset allocation in stocks, bonds, then risk-free at time 0
	-Rows 14-17 will display optimal asset allocations in stock, bonds and risk free at time 1 depending on which scenario you are in
	-Rows 18-33 will display optimal asset allocation for time 2 depending on the scenario
	-Rows 34-97 will display optimal asset allocation for time 3 depending on the scenario
	-Rows 98-353 will display optimal asset allocation for time 4 depending on scenario
	-Row 354-1377 will display asset allocation for time 5, however these will generally be split evenly across all assets as this is the end of the investment horizon
	-Row 1378 will display 0, 0; ignore this line
	-Rows 1379-1382 will display the amount you are below time 1 goals, and amount you are above time 1 goals depending on your scenario
	-Rows 1383-1398 will display the amount you are below time 2 goals, and amount you are above time 2 goals depending on your scenario
	-Rows 1399-1462 will display the amount you are below time 3 goals, and amount you are above time 3 goals, depending on your scenario
	-Rows 1463-1718 will display the amount you are below time 4 goals and amount you are above time 4 goals, depending on your scenario
	-Rows 1719-2742 will display the amount you are below time 5 goals and amount you are above time 5 goals, depending on your scenario